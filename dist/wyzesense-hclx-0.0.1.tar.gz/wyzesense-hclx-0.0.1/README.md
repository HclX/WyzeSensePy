# WyzeSensePy
WyzeSensePy is a python package trying to implement the communication protocol between WyzeCamera and WyzeSense USB dongle. 
